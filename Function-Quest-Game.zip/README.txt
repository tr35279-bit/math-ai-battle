FUNCTION QUEST
================

ไฟล์เกม:
- index.html = เกมพร้อมเล่น

QR Code:
- QR_Code_เกม.png

สำคัญ:
QR ตอนนี้ตั้งค่าไว้ที่:
https://YOUR-USERNAME.github.io/function-quest/

เพราะ QR Code ต้องชี้ไปยัง URL ที่เปิดจากโทรศัพท์ได้จริง จึงต้องอัปโหลด index.html ไปยัง GitHub Pages ก่อน
แล้วเปลี่ยน QR เป็น URL จริง เช่น:
https://ชื่อผู้ใช้.github.io/function-quest/

ตัวเกมสามารถเปิด index.html ในเบราว์เซอร์ได้โดยตรงโดยไม่ต้องติดตั้งอะไร
